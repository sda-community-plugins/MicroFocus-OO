package com.serena.air

class UrlHelper {

    /**
     * <pre>
     * How to use:
     *      String fullUrl =
     *      completeUrl(input, 'aaa/bbb/ccc.wsdl'){String urlGuess ->
     *          return isUrlValid(urlGuess) //implement your check
     *      }
     * Example:
     *      for template 'aaa/bbb/ccc.wsdl' and user input 'http://host:port/'
     *      your checking function will be called with values:
     *          'http://host:port/'
     *          'http://host:port/aaa/bbb/ccc.wsdl'
     * </pre>
     */
    public static String completeUrl(String input, String template, Closure urlCheck) {
        return doSilently() {
            if(urlCheck == null){
                throw new IllegalArgumentException('urlCheck closure must be not null!')
            }

            if (urlCheck(input)) {
                return input
            }
            String concat = concatUrls(input, template)
            if (urlCheck(concat)) {
                return concat
            }
            return null
        }
    }


    //TODO will be moved to other class later, dont use in plugins directly yet
    private static <V> V doSilently(Closure<V> clos) {
        PrintStream sout = System.out
        PrintStream serr = System.err
        V result = null
        try {
            def devnull = new PrintStream(new OutputStream() {
                @Override
                void write(int b) throws IOException {
                    //do nothing
                }
            })
            System.setOut(devnull)
            System.setErr(devnull)
            result = clos()
        } finally {
            System.setOut(sout)
            System.setOut(serr)
        }
        return result
    }

    public static String concatUrls(String root, String addition) {
        StringBuilder sb = new StringBuilder()
        if (root.endsWith('/')) {
            sb.append(root)
        } else {
            sb.append(root)
            sb.append('/')
        }

        if (addition.startsWith('/')) {
            sb.append(addition.substring(1))
        } else {
            sb.append(addition)
        }

        return sb.toString()
    }

}
